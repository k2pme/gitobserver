from  .watcher import start_watcher

if __name__ == "__main__":
    start_watcher()
